package com.axyya.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UseCaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
